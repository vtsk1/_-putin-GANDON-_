from django.contrib.auth.management.commands.changepassword import Command

__all__ = ["Command"]
